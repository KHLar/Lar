package com.misoot.lar.home.model.vo;

import java.util.List;

import com.misoot.lar.lecture.model.vo.Lecture;

public class Home implements java.io.Serializable {
	List<Lecture> recommend_lec_list;
}